<!DOCTYPE html>
<html lang="en">
<head>
    <title>Minha Página Bootstrap</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script> 
    $(document).ready(function(){
        $("#footer").click(function(){
        $("#contact-panel").slideDown("slow");
        });
    });
    </script>
    <style>
    body{
        background-color: #adadad;
    }
    .header, .footer {
        background-color: #333;
        color: white;
        padding: 20px;
        text-align: center;
        cursor: pointer;
    }
    .custom-img {
        width: 100%;
        height: auto;
        object-fit: cover;
    }
    .img-filme {
        width: 400px;
        height: 600px;
        object-fit: cover;
    }
    .img-sonho {
        width: 600px;
        height: 400px;
        object-fit: cover;
    }
    .col-md-4, .col-md-6, .col-md-12 {
        padding: 20px;
    }
    .title {
        text-align: center;
        margin-bottom: 20px;
    }
    #contact-panel {
        display: none;
        padding: 20px;
        background-color:rgb(100, 100, 100);
        border: solid 1pxrgb(216, 216, 216);
        text-align: center;
        color: white;
    }
    </style>
</head>
<body>

<div class="header">
    <h1>Sobre Mim</h1>
    <p>Essa página foi criada com o intuito de que você, usuário, me conheça melhor.</p> 
</div>

<div class="container mt-5">
    <h1>Me conheça</h1>
    <p>Olá, meu nome é Pablo, tenho 18 anos e estudo Informática para Internet no IFSP Guarulhos. Sou uma pessoa sociável e curto sair com meus amigos sempre que tenho um tempo livre. No futuro, quero seguir na área de Fisioterapia ou Biologia, e mais pra frente, quem sabe, Gastronomia. No dia a dia, passo o tempo ouvindo música e jogando, duas coisas que gosto muito.</p>
    <h2 class="title">Cantores Favoritos</h2>
    <div class="row text-center">
        <div class="col-md-4">
            <h3>Laufey</h3>
            <img src="imagens/laufey.jpg" class="img-fluid rounded custom-img" alt="Laufey">
            <p>Laufey Lín Jónsdóttir (23 de abril de 1999), conhecida pelo monônimo Laufey (pronunciado lei-vei), é uma cantora e compositora islandesa. Ela lançou seu EP de estreia, Typical of Me, em 2021. Ela descreve seu estilo como jazz moderno, uma mistura de jazz com bossa nova.</p>
        </div>
        <div class="col-md-4">
            <h3>Arctic Monkeys</h3>
            <img src="imagens/arctic.jpg" class="img-fluid rounded custom-img" alt="Arctic">
            <p>Arctic Monkeys é uma banda britânica de rock formada em 2002 nos subúrbios da cidade de Sheffield, na Inglaterra. O grupo é formado por Alex Turner (vocal, guitarra), Matt Helders (bateria, voz de apoio), Jamie Cook (guitarra) e Nick O'Malley (baixo, voz de apoio). A banda é considerada uma das primeiras a ganhar atenção na internet, causando mudanças no cenário musical.</p>
        </div>
        <div class="col-md-4">
            <h3>Jorge Rivera-Herrans</h3>        
            <img src="imagens/jorge.jpg" class="img-fluid rounded custom-img" alt="Jorge">
            <p>Jorge Miguel Rivera-Herrans é o criador de EPIC: The Musical e o fundador da Winion Entertainment LLC. Ele interpretou os papéis de Odisseu, os Winions e Polifemo. Ele começou a trabalhar em EPIC em junho de 2019, em seu dormitório universitário. Ele queria criar um musical inspirado em videogames e anime/mangá para "emular sua sensação viciante de progressão".</p>
        </div>
    </div>

    <h2 class="title">Filmes Favoritos</h2>
    <div class="row text-center">
        <div class="col-md-6">
            <h3>Como Treinar seu Dragão</h3>
            <img src="imagens/ctsd.jpg" class="img-fluid rounded img-filme" alt="CTSD">
            <h4>Sinopse</h4>
            <p>Soluço é um jovem viking que não tem capacidade para lutar contra os dragões, como é a tradição local. Sua vida muda quando ele ajuda um dragão que lhe mostra toda a verdade. Juntos, eles tentam provar que dragões e humanos podem ser amigos.</p>
        </div>
        <div class="col-md-6">
            <h3>Kung fu Panda</h3>
            <img src="imagens/kfp.jpg" class="img-fluid rounded img-filme" alt="KFP">
            <h4>Sinopse</h4>
            <p>Po é um panda que trabalha na loja de macarrão da sua família e sonha em transformar-se em um mestre de kung fu. Seu sonho se torna realidade quando, inesperadamente, ele deve cumprir uma profecia antiga e estudar a arte marcial com seus ídolos, os Cinco Furiosos. Po precisa de toda a sabedoria, força e habilidade que conseguir reunir para proteger seu povo de um leopardo da neve malvado.</p>
        </div>
    </div>

    <h2 class="title">Sonho</h2>
    <div class="row text-center">
        <div class="col-md-12">
            <img src="imagens/lcb.jpg" class="img-fluid rounded img-sonho" alt="LCB">
            <p>O Le Cordon Bleu (fita azul, em francês) é uma rede internacional de ensino de gestão de hospitalidade e de escolas de culinária que ensinam cozinha francesa. Por ser uma rede de ensino tão prestigiada, diversos chefs famosos e experientes já passaram por ela durante suas formações acadêmicas. Meu sonho é um dia poder estudar nessa instituição, e poder trabalhar num restaurante que possua alguma estrela Michelin</p>
        </div>
    </div>
</div>

<div id="footer" class="footer">
    &copy; PABLO HENRIQUE DE LIMA SANTOS
</div>

<div id="contact-panel">
    <h3>Formas de Contato</h3>
    <p>GitHub: hanrrico</p>
    <p>LinkedIn: <a href="https://www.linkedin.com/in/pablo-lima-santos-a8b619321/" target="_blank">Pablo</a></p>
</div>

</body>
</html>